import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rigister',
  templateUrl: './rigister.component.html',
  styleUrls: ['./rigister.component.css']
})
export class RigisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
