import { Injectable } from '@angular/core';
import { book } from 'src/Model/Booking';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private booking:Booking[]=[];
  constructor() { 
    let b1=new Booking
  }
}
